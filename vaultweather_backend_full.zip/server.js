
// server.js - Entry point for Render
require('./vaultboard-api-port3100');
