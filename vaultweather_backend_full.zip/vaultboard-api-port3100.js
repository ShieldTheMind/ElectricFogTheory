
// vaultboard-api-port3100.js - Main API Logic
const express = require('express');
const app = express();
const PORT = process.env.PORT || 10000;

app.get('/', (req, res) => {
  res.send('VaultWeather API is live and connected.');
});

app.listen(PORT, () => {
  console.log(`VaultWeather API listening on port ${PORT}`);
});
