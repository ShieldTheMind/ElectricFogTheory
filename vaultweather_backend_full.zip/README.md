
# VaultWeather Backend

This is the backend system powering VaultWeather. It provides real-time atmospheric forecasting, drift detection, and scroll logic.

## Setup

1. Clone this repository
2. Copy `.env.example` to `.env` and fill in your OpenWeather API key
3. Run the server:

```
npm install
npm start
```

## API

- `/` - Health check endpoint
