# VaultWeather

VaultWeather is a real-time atmospheric intelligence engine that learns from its own forecast errors.
It tracks confidence, drift, and scroll-based logic using MongoDB + Node.js.

## Live Components

- **Forecast Scheduler** – Rotating API ingestion + drift calculation  
- **VaultBoard API** – Live backend for node memory  
- **VaultBoard Frontend** – Dashboard with scroll-trigger alerts  
- **MongoDB** – Full memory log + real-time learning

## Setup

1. `npm install`  
2. Create `.env` using `.env.example`  
3. Run:
   - `node scheduler.js`
   - `node vaultboard-api-port3100.js`
   - `npx serve .` (to view dashboard)

## Demo

Live system: [vaultweather-api.onrender.com](https://vaultweather-api.onrender.com)
