require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const { NodeMemory } = require('./vault-node-memory');

const app = express();
const PORT = process.env.PORT || 3100;

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost/vaultweather', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log("MongoDB connected to VaultBoard API");
}).catch(err => {
  console.error("MongoDB connection error:", err);
});

app.get('/api/nodes', async (req, res) => {
  try {
    const nodes = await NodeMemory.find({}).sort({ confidenceScore: -1 });
    const data = nodes.map(n => ({
      node: n.nodeId,
      confidence: n.confidenceScore,
      drift: n.averageDriftScore
    }));
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch node memory' });
  }
});

app.listen(PORT, () => {
  console.log(`VaultBoard API listening on port ${PORT}`);
});