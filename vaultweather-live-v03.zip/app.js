const API_KEY = 'a723c030e05a82a5d0277633c3f17687';
const CITY = 'Madison';
const STATE = 'MS';
const API_URL = `https://api.openweathermap.org/data/2.5/forecast/daily?q=${CITY},${STATE},US&cnt=7&units=imperial&appid=${API_KEY}`;

fetch(API_URL)
    .then(response => response.json())
    .then(data => {
        const tableBody = document.querySelector("#forecast tbody");
        data.list.forEach(day => {
            const row = document.createElement("tr");
            const date = new Date(day.dt * 1000).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
            row.innerHTML = `
                <td>${date}</td>
                <td>${Math.round(day.temp.max)}°</td>
                <td>${Math.round(day.temp.min)}°</td>
                <td>${day.pop ? Math.round(day.pop * 100) : 0}%</td>
                <td><img src="https://openweathermap.org/img/wn/${day.weather[0].icon}.png" alt="icon"></td>
            `;
            tableBody.appendChild(row);
        });
    })
    .catch(error => console.error("Weather fetch failed:", error));
