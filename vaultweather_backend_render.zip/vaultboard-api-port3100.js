
const express = require('express');
const app = express();
const PORT = process.env.PORT || 10000;

app.get('/', (req, res) => {
  res.send('VaultWeather API is live.');
});

app.listen(PORT, () => {
  console.log(`VaultWeather API listening on port ${PORT}`);
});
