
document.addEventListener("DOMContentLoaded", () => {
  fetch('/api/forecast/vault')
    .then(res => res.json())
    .then(data => {
      document.getElementById('vaultscore').innerText = data.vaultResonanceIndex;
    }).catch(() => {
      document.getElementById('vaultscore').innerText = "Unavailable";
    });

  fetch('/api/solar')
    .then(res => res.json())
    .then(data => {
      document.getElementById('solar').innerText = `☀️ Solar: ${data.solarRadiation} ${data.unit}`;
    }).catch(() => {
      document.getElementById('solar').innerText = "☀️ Solar: Unavailable";
    });

  fetch('/api/moon')
    .then(res => res.json())
    .then(data => {
      document.getElementById('lunar').innerText = `🌕 Lunar: ${data.moonPhase}, ${data.illumination}`;
    }).catch(() => {
      document.getElementById('lunar').innerText = "🌕 Lunar: Unavailable";
    });
});
