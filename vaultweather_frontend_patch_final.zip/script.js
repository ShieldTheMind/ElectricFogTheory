
const apiKey = 'a723c030e05a82a5d0277633c3f17687';

const weatherUrl = `https://api.openweathermap.org/data/2.5/onecall?lat=32.4562&lon=-90.1152&units=imperial&appid=${apiKey}`;

fetch(weatherUrl)
  .then(response => response.json())
  .then(data => {
    const solar = data.current.sunrise;
    const lunar = data.daily[0].moon_phase;

    document.getElementById("solar").innerText = `Sunrise: ${new Date(solar * 1000).toLocaleTimeString()}`;
    document.getElementById("lunar").innerText = `Moon Phase: ${lunar}`;
    document.getElementById("vault").innerText = "VaultScore: Online";
  })
  .catch(error => {
    document.getElementById("solar").innerText = "Unavailable";
    document.getElementById("lunar").innerText = "Unavailable";
    document.getElementById("vault").innerText = "Error loading VaultScore";
  });

setTimeout(() => {
  if (document.getElementById("solar").innerText === "Loading...") {
    document.getElementById("solar").innerText = "Unavailable";
    document.getElementById("lunar").innerText = "Unavailable";
    document.getElementById("vault").innerText = "Unavailable";
  }
}, 5000);
