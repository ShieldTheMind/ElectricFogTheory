const express = require('express');
const axios = require('axios');
const app = express();
const port = 10000;

app.get('/api/solar', async (req, res) => {
    res.json({ solarRadiation: 1361, unit: "W/m²", status: "simulated" });
});

app.get('/api/moon', async (req, res) => {
    res.json({ moonPhase: "Waxing Gibbous", illumination: "72%", status: "simulated" });
});

app.get('/api/forecast/vault', async (req, res) => {
    res.json({ vaultResonanceIndex: 0.82, solarImpact: "moderate", lunarTideEffect: "elevated" });
});

app.listen(port, () => {
    console.log(`VaultWeather API running on port ${port}`);
});